var config          = require('../config.json');
if(!config.tasks.scripts) return;

var gulp            = require('gulp'),
    jshint          = require('gulp-jshint'),
    concat          = require('gulp-concat'),
    rename          = require('gulp-rename'),
    uglify          = require('gulp-uglify'),
    sourcemaps      = require('gulp-sourcemaps'),
    notify          = require('gulp-notify'),
    livereload      = require('gulp-livereload'),
    del             = require('del'),
    gutil           = require('gulp-util');

var scriptsTask = function() {
  //Remove old files
  del.sync(config.tasks.scripts.jsDest, {force:true});

  // Lint Task
  // gulp.src(config.tasks.scripts.jsSourceFiles)
  // .pipe(jshint())
  // .pipe(jshint.reporter('default'));

  //concatenate & minify
  gulp.src(config.tasks.scripts.jsSourceFiles)
  .pipe(sourcemaps.init({
    largeFile: true
  }))
  .pipe(concat(config.tasks.scripts.concatJs))
  .pipe(rename(config.tasks.scripts.productionJs))
  .pipe(uglify())
  .on('error', gutil.log)
  .pipe(sourcemaps.write(config.tasks.scripts.sourcemapDest, {
    sourceRoot: config.tasks.scripts.sourcemapSourceRoot,
    sourceMappingURLPrefix: config.tasks.scripts.sourcemapDest
  }))
  .pipe(gulp.dest(config.tasks.scripts.jsDest))
  .pipe(notify({message: 'Scripts task complete'}));

  // Merges and minifies JS Library files
  // gulp.src(config.tasks.scripts.jsLibrarySourceFiles)
  // .pipe(sourcemaps.init({
  //   largeFile: true
  // }))
  // .pipe(concat(config.tasks.scripts.jsLibraries))
  // .pipe(gulp.dest(config.tasks.scripts.jsDest))

  // .pipe(rename(config.tasks.scripts.jsLibrariesMinified))
  // .pipe(uglify())
  // .pipe(sourcemaps.write(config.tasks.scripts.sourcemapDest, {
  //   sourceRoot: config.tasks.scripts.sourcemapSourceRoot,
  //   sourceMappingURLPrefix: config.tasks.scripts.sourcemapDest
  // }))
  // .pipe(gulp.dest(config.tasks.scripts.jsDest))
  // .pipe(notify({message: 'Scripts (Libraries) task complete'}));


  // Error handling
  gulp.on('err', function(err){
      console.log(err);
  });

  livereload.listen();
};

gulp.task('scripts', scriptsTask);
gulp.watch(config.tasks.scripts.watchFiles, config.tasks.scripts.watchTasks);