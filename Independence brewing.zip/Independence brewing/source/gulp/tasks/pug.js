var config       = require('../config.json')
if(!config.tasks.pug) return

var gulp   = require('gulp'),
    notify = require('gulp-notify'),
    pug    = require('gulp-pug');
 
var pugTask = function(){
  gulp.src(config.tasks.pug.source)
    .pipe(pug({pretty: true}))
    .pipe(gulp.dest(config.tasks.pug.destination))
    .pipe(notify({message: 'Pug task complete'}));
};

gulp.task('pug', pugTask);
gulp.watch(config.tasks.pug.watch, pugTask);