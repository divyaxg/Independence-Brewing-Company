var config       = require('../config.json')
if(!config.tasks.rev) return

var gulp      = require('gulp'),
    notify    = require('gulp-notify'),
    del       = require('del'),
    rev       = require('gulp-rev');

var revTask = function(){
    setTimeout(function(){
        gulp
        .src(config.tasks.rev.sourceFiles)
        .pipe(rev())
        .pipe(gulp.dest(config.tasks.rev.destinationDirectory))
        .pipe(rev.manifest('manifest.json'))
        .pipe(gulp.dest(config.tasks.rev.manifestFileDest))
        .pipe(notify({message: 'Rev task complete'}));
    },1000);
};

var cssRevTask = function(){
    setTimeout(function(){
        gulp
        .src(config.tasks.rev.cssSourceFiles)
        .pipe(rev())
        .pipe(gulp.dest(config.tasks.rev.destinationDirectory))
        .pipe(rev.manifest('manifest.json'))
        .pipe(gulp.dest(config.tasks.rev.manifestFileDest))
        .pipe(notify({message: 'CSS Rev task complete'}));
    },1000);
};


var jsRevTask = function(){
    setTimeout(function(){
        gulp
        .src(config.tasks.rev.jsSourceFiles)
        .pipe(rev())
        .pipe(gulp.dest(config.tasks.rev.destinationDirectory))
        .pipe(rev.manifest('manifest.json'))
        .pipe(gulp.dest(config.tasks.rev.manifestFileDest))
        .pipe(notify({message: 'JS Rev task complete'}));
    },1000);
};
  
gulp.task('rev', revTask);
gulp.task('cssRev', cssRevTask);
gulp.task('jsRev', jsRevTask);